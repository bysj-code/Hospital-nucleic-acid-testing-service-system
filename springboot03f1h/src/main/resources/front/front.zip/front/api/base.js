﻿const base = {
        url : "http://localhost:8080/springboot03f1h/"
    }
export default base